package com.example.jejuddai;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JejuddaiApplication {

	public static void main(String[] args) {
		SpringApplication.run(JejuddaiApplication.class, args);
	}

}
