package com.example.jejuddai;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JejuddaiApplicationTests {

	@Test
	void contextLoads() {
	}

}
